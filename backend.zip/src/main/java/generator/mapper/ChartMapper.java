package generator.mapper;

import generator.domain.Chart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author CNHan
* @description 针对表【chart(图表信息表)】的数据库操作Mapper
* @createDate 2025-04-08 20:55:51
* @Entity generator.domain.Chart
*/
public interface ChartMapper extends BaseMapper<Chart> {

}




