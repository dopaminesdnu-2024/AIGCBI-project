package com.hcn.springbootinit.mapper;

import com.hcn.springbootinit.model.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.yupi.springbootinit.model.entity.User
 */
public interface UserMapper extends BaseMapper<User> {

}




